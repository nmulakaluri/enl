'use strict';

/**
 * @ngdoc function
 * @name enlApp.controller:AboutCtrl
 * @description
 * # AboutCtrl
 * Controller of the enlApp
 */
angular.module('enlApp')
  .controller('AboutCtrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
